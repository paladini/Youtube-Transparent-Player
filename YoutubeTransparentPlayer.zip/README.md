Youtube Transparent Player
==================

Do you want to test the new Youtube Transparent Player? Currently only a few people can have this nice Youtube player, but this extension cheat that allowing you to use this awesome Youtube player.

Following is a screenshot comparing between the two players:
![Comparison between new and old Youtube player](http://3.bp.blogspot.com/-n8qQ5Df14tU/VSmMSc11ghI/AAAAAAACCOM/Nv_bFypknjE/s1600/youtube-new-player-ui-3.png)

You can find this extension at [Chrome Web Store](https://chrome.google.com/webstore/category/apps) for free.

About
==================
"Youtube Transparent Player" was written by Fernando Paladini in only a few minutes of April 13, 2015. 

If you like it, star, suggest issues, share, improve the code or even fork and create your own extension!

License
==================
You can find the project terms of use in the file named "LICENSE". If you don't want open that file, "Youtube Transparent Player" is licensed under MIT.




